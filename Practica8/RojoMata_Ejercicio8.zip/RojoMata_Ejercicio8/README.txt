# Ejercio 8, Palíndromos

# Rojo Mata Daniel


El algoritmo verifica si una cadena es un palíndromo o no. 
En caso se serlo se devuelve true, en caso contrario false. 
La implementación se hace mediante el uso de pilas y colas.



## Compilación y Ejecución

1. Asegurárse de tener Java JDK instalado en el sistema.
2. Descargar o clonar este archivo en la computadora.
3. Abrir la terminal y navegar hasta la carpeta del proyecto.

### Compilación

Ejecutar el siguiente comando para compilar el proyecto:

javac *.java


