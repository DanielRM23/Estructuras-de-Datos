# Práctica 9, Implementación de la EDD Gráfica

# Matú Hernández Diana
# Rojo Mata Daniel

Implementación en Java de los siguientes métodos para la EDD Gráfica
1.- eliminarVertice
2.- eliminarArista
3.- darVecindad
4.- darGrado
5.- darVertice

## Compilación y Ejecución

1. Asegurárse de tener Java JDK instalado en el sistema.
2. Descargar o clonar este archivo en la computadora.
3. Abrir la terminal y navegar hasta la carpeta del proyecto.

### Compilación

Ejecutar el siguiente comando para compilar el proyecto:

javac *.java


