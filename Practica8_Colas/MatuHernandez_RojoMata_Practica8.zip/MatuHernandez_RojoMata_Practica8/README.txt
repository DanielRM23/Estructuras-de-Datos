# Práctica 8, Implementación de la EDD Cola

# Matú Hernández Diana
# Rojo Mata Daniel

Implementación en Java de la EDD Cola con los siguientes métodos
Constructor
encolar
desencolar
darElementoInicio
esVacia
darLongitud

## Compilación y Ejecución

1. Asegurárse de tener Java JDK instalado en el sistema.
2. Descargar o clonar este archivo en la computadora.
3. Abrir la terminal y navegar hasta la carpeta del proyecto.

### Compilación

Ejecutar el siguiente comando para compilar el proyecto:

javac *.java


