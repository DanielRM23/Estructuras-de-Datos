# Práctica 6, Implementación de la Clase Nodo

# Matú Hernández Diana
# Rojo Mata Daniel

Implementación en Java de la clase ‘Nodo‘con los siguientes métodos
modificarElemento
darElmento
modificarSiguiente
darSiguiente 

## Compilación y Ejecución

1. Asegurárse de tener Java JDK instalado en el sistema.
2. Descargar o clonar este archivo en la computadora.
3. Abrir la terminal y navegar hasta la carpeta del proyecto.

### Compilación

Ejecutar el siguiente comando para compilar el proyecto:

javac *.java


