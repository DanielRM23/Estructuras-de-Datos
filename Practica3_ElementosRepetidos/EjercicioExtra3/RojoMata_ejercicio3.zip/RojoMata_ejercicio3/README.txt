# Ejercicio extra, Práctica 3

# Rojo Mata Daniel

Se realizan los alguritmos de manera iterativa para las funciones de Fibonacci y factorial.

## Compilación y Ejecución

1. Asegurárse de tener Java JDK instalado en el sistema.
2. Descargar o clonar este archivo en la computadora.
3. Abrir la terminal y navegar hasta la carpeta del proyecto.

### Compilación

Ejecutar el siguiente comando para compilar el proyecto:

javac *.java


