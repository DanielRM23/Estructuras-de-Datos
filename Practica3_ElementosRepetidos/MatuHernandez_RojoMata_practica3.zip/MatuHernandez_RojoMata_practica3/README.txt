# Práctica 3, elementos repetidos

# Matú Hernández Diana
# Rojo Mata Daniel

Se resuelve el siguiente problema: dada una secuencia S no vacía y finita de n numeros enteros ordenados de manera creciente, eliminar los elementos
repetidos de la secuencia.
La secuencia S es vista como un array de n elementos enteros.

## Compilación y Ejecución

1. Asegurárse de tener Java JDK instalado en el sistema.
2. Descargar o clonar este archivo en la computadora.
3. Abrir la terminal y navegar hasta la carpeta del proyecto.

### Compilación

Ejecutar el siguiente comando para compilar el proyecto:

javac *.java


