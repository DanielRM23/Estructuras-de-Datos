# Práctica 5, Búsqueda Binaria y Secuencial 

# Matú Hernández Diana
# Rojo Mata Daniel

El problema a resolver es el siguiente:
Dados un arreglo A y un entero x, devolver el primer  ́ındice i del arreglo tal que A[i] = x en caso de que x se
encuentre en el arreglo, en caso contrario devolvemos -1.

## Compilación y Ejecución

1. Asegurárse de tener Java JDK instalado en el sistema.
2. Descargar o clonar este archivo en la computadora.
3. Abrir la terminal y navegar hasta la carpeta del proyecto.

### Compilación

Ejecutar el siguiente comando para compilar el proyecto:

javac *.java


