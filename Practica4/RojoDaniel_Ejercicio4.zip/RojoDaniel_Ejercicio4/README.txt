# Ejercicio 4, mediana

# Rojo Mata Daniel

Sean A y B dos arreglos de enteros no ordenados, de longitud n cada uno. 
Calcular la mediana del arreglo, de
tama ̃no 2n, formado por la combinaci ́on de los arreglos A y B.

## Compilación y Ejecución

1. Asegurárse de tener Java JDK instalado en el sistema.
2. Descargar o clonar este archivo en la computadora.
3. Abrir la terminal y navegar hasta la carpeta del proyecto.

### Compilación

Ejecutar el siguiente comando para compilar el proyecto:

javac *.java


