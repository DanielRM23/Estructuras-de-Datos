# Práctica 4, ordenar dos arreglos en uno

# Matú Hernández Diana
# Rojo Mata Daniel

El problema a resolver es el siguiente:
Dados dos arreglos de enteros ordenados A y B, cada uno de longitud n, 
devuelve un arreglo de tama ̃no 2n que
contenga los elementos de A y B en orden creciente.

## Compilación y Ejecución

1. Asegurárse de tener Java JDK instalado en el sistema.
2. Descargar o clonar este archivo en la computadora.
3. Abrir la terminal y navegar hasta la carpeta del proyecto.

### Compilación

Ejecutar el siguiente comando para compilar el proyecto:

javac *.java


